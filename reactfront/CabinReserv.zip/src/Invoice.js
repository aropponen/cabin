import React, { Component } from "react";
 
export default class Invoice extends Component {
  render() {
    return (
      <div>
        <h2>Tähän tulee laskut</h2>

      </div>
    );
  }
}