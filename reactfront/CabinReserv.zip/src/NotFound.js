import React, { Component } from "react";
import './NotFound.css'
 
export default class NotFound extends Component {
    render() {
      return (
        <div>
            <p className={'notFound'}>
            404 - Sivua ei löydy!
            </p>
            
        </div>
      );
    }
}