import React from 'react'

export const ReservationContext = React.createContext("Tämä tulee myContextista");
