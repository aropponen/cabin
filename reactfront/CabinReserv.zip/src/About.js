import React, { Component } from 'react'

export default class About extends Component {
    render() {
      return (
        <div>
          <p>Village People Oy on vuonna 2006 perustettu vapaa-ajan matkailun edelläkävijä. <br />
            Tarjoamme erilaisia majoitusratkaisuja kiireisille ja ei niin kiireisille kuluttajille, <br />
            yrityksille sekä yhteisöille. Toimintamme laajenee koko valtakunnan alueelle vuoden <br />
            2020 alusta alkaen. Uudet toimipisteemme löydät mm. Rukalta, Tahkolta ja Ylläkseltä. <br />
            Toimipaikkoja meillä on Suomessa yhteensä 35 kappaletta <br />
            ja työllistämme tällä hetkellä 189 ihmistä. Tarjoamme majoituksen lisäksi erilaisia <br />
            seikkailupalveluita, kuten porosafarit, koiravaljakkoajelut, airsoft, <br />
            hevos- sekä vesiskootteriajelut. Tutustu tarjontaamme ja jos ei haluamaasi palvelua <br />
            vielä löydy, voit jättää meille palautetta niin laitamme sen tapahtumaan.</p>

          <h4>Tue paikallista yrittäjää korona-kriisin keskellä.</h4>
          <h4>Varaa kesäksi mökki ja vietä lomasi rentouttavissa järvimaisemissa!</h4>
        </div>
      );
    }
}