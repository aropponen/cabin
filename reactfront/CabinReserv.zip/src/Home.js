import React, { Component } from 'react';
import "./App.css";
import { ReservationContext } from './myContext';

export default class Home extends Component {
  static contextType = ReservationContext;

  logout() {
    var emptyData = {
      userRole: 0,
      loggedInUser: "",
      cabinId: "",
      customerId: ""
    }
    const ctx = this.context;
    ctx.updateData(null);
    console.log("Tyhnennetty: ", emptyData)
  }
    render() {
      
        return  (    
          <div>  
            <p>Nyt ollaan etusivulla.</p>
            <button className="btn btn-danger" onClick={this.logout}>
                            Logout
                        </button>
          </div>   
          )
    }
}