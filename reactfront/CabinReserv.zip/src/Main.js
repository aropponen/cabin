import React, { Component } from 'react' 
import { BrowserRouter as HashRouter, Route, NavLink, Switch } from "react-router-dom"; 
import "bootstrap/dist/css/bootstrap.min.css"; 
import Home from "./Home";
import Resort from "./Resort"; 
import Cabin from "./Cabin"; 
import Service from "./Service"; 
import Customer from "./Customer"; 
import Reservation from "./Reservation"; 
import Invoice from "./Invoice";
import About from "./About"; 
import Contact from "./Contact"; 
import Login from "./components/login.component"; 
import Register from "./components/register.component"; 
import NotFound from "./NotFound"; 

import {ReservationContext} from "./myContext" 

export default class Main extends Component { 
  static contextType = ReservationContext;

  constructor(props) { 
    super(props); 
    this.state = { 
    }; 
  }

  logout() {

    this.setState(null)
  }

  render() { 
      /* const data = this.context;
      const roleOfTheUser = this.state.asiakasData.userRole;
      console.log("Useri on : ", roleOfTheUser)

      const joku = this.context;
      console.log("x=", joku)
      let luku = joku.number;
      joku.number = 300;
      let data = joku.customerData.loggedUser;*/

    return ( 
      //<ReservationContext.Provider value={this.state}> TÄMÄ ORKKIS KIVI JA KEPPI VERSIO 1#

      <ReservationContext.Provider value={{
        data: this.state, 
        updateData: (asiakasData) => {
        console.log("Contextissa parametri eli kaikki tiedot: ", asiakasData);
        console.log("Contextissa asiakasData.userRole ja loggedInUser ", asiakasData.userRole, asiakasData.loggedInUser,);

        this.setState({uusiData: asiakasData})
        }
      }}>
        


      <HashRouter> 
        <div> 
          <div> 
            <h1>Village People Oy</h1> 
            <h2>Mökkivarausjärjestelmä</h2> 
            <ul className="header"> 
              <li><NavLink to="/">Kotisivu</NavLink></li> 
              <li><NavLink to="/resort">Toimipaikat</NavLink></li> 
              <li><NavLink to="/cabin">Mökit</NavLink></li> 
              <li><NavLink to="/service">Palvelut</NavLink></li> 
              <li><NavLink to="/customer">Asiakkaat</NavLink></li> 
              <li><NavLink to="/reservation">Varaukset</NavLink></li> 
              <li><NavLink to="/invoice">Laskut</NavLink></li> 
              <li><NavLink to="/about">Meistä</NavLink></li> 
              <li><NavLink to="/contact">Yhteystiedot</NavLink></li> 
              <li><NavLink to="/login">Kirjaudu </NavLink> </li> 
              <li><NavLink to="/register">Rekisteröidy</NavLink></li> 
            </ul> 
          </div> 
        </div> 

        <div className="content"> 
          <Switch> 
            <Route path="/" exact component={Home} /> 
            <Route path="/resort" component={Resort} /> 
            <Route path="/cabin" component={Cabin} /> 
            <Route path="/service" component={Service} /> 
            <Route path="/customer" component={Customer} /> 
            <Route path="/reservation" component={Reservation} /> 
            <Route path="/invoice" component={Invoice} /> 
            <Route path="/about" component={About} /> 
            <Route path="/contact" component={Contact} /> 
            <Route path="/login" component={Login} /> 
            <Route path="/register" component={Register} /> 
            <Route path="*" component={NotFound} /> 
          </Switch> 
        </div> 
      </HashRouter> 
      </ReservationContext.Provider> 
    ); 
  } 
} 